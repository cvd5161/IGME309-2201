/* Comments */

#include "Main.H"

int main()
{
	std::cout << "Hello World\n";
	
	//Ending the Program
	std::cout << "Press enter to finish";
	getchar();
	return 0;
}